package stable_seeding_bot;

import battlecode.common.GameActionException;

public class Refinery {
  static void runRefinery() throws GameActionException {
  }
}
