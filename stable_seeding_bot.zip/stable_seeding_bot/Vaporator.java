package stable_seeding_bot;

import battlecode.common.GameActionException;

public class Vaporator {
  static void runVaporator() throws GameActionException {
    Comms.getBlocks();
  }
}
