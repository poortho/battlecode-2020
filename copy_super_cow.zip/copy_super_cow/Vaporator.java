package copy_super_cow;

import battlecode.common.GameActionException;

public class Vaporator {
  static void runVaporator() throws GameActionException {
    Comms.getBlocks();
  }
}
