package copy_super_cow;

import battlecode.common.GameActionException;

public class Refinery {
  static void runRefinery() throws GameActionException {
    Comms.getBlocks();
  }
}
