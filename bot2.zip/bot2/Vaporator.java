package bot2;

import battlecode.common.GameActionException;

public class Vaporator {
  static void runVaporator() throws GameActionException {
  }
}
