package bot2;

import battlecode.common.GameActionException;

public class Refinery {
  static void runRefinery() throws GameActionException {
  }
}
